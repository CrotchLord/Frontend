const select = document.querySelector(".select");
const options_list = document.querySelector(".options-list");
const options = document.querySelectorAll(".option");

// Check if elements are found before adding event listeners
if (select && options_list && options) {
    // show & hide options list
    select.addEventListener("click", () => {
        options_list.classList.toggle("active");
        select.querySelector(".fa-angle-down").classList.toggle("fa-angle-up");
    });

    // select option
    options.forEach((option) => {
        option.addEventListener("click", () => {
            options.forEach((opt) => opt.classList.remove('selected'));
            select.querySelector("span").innerHTML = option.innerHTML;
            option.classList.add("selected");
            options_list.classList.toggle("active");
            select.querySelector(".fa-angle-down").classList.toggle("fa-angle-up");
        });
    });
}
