/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        cool: '#201e1e',
        bool: '#f9f9f9',
      }
    },
  },
  plugins: [],
}